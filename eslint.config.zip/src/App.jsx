import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './components/Login';
import Register from './components/Register';
import CreateRoom from './components/CreateRoom';
import JoinRoom from './components/JoinRoom';
import Room from './components/Room';
import TicTacToe from './components/TicTacToe';
import { WebSocketProvider } from "./components/WebsocketContext";
import SnakeAndLadder from './components/SnakeAndLadder';

const App = () => {
    return (
        <Router>
            <WebSocketProvider>
                <Routes>
                    <Route path="/" element={<Login />} />
                    <Route path="/register" element={<Register />} />
                    <Route path="/create-room" element={<CreateRoom />} />
                    <Route path="/join-room" element={<JoinRoom />} />
                    <Route path="/room/:roomName" element={<Room />} />
                    <Route path="/game/tic-tac-toe/:roomName" element={<TicTacToe />} />
                    <Route path="/game/snake-and-ladder/:roomName" element={<SnakeAndLadder />} />
                </Routes>
            </WebSocketProvider>
        </Router>
    );
};

export default App;
