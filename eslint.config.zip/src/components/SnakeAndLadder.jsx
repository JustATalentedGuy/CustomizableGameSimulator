import React, { useState, useEffect } from 'react';
import { useParams, useLocation } from 'react-router-dom';
import { useWebSocket } from './WebsocketContext';
import './SnakeAndLadder.css';

const SnakeAndLadder = () => {
    const { roomName } = useParams();
    const location = useLocation();
    const { messages, send } = useWebSocket();
    const gridSize = location.state?.config?.gridSize || 10;
    const snakes = location.state?.config?.snakes || {};
    const ladders = location.state?.config?.ladders || {};
    const playerSymbol = location.state?.symbol; 

    const [playerPosition, setPlayerPosition] = useState(1);
    const [opponentPlayerPosition, setOpponentPlayerPosition] = useState(1);
    const [isRedNext, setIsRedNext] = useState(true);
    const [roll, setRoll] = useState(null);
    const [gameOver, setGameOver] = useState(false);

    useEffect(() => {
        if (!messages.length) return;
        const latestMessage = messages[messages.length - 1];

        if (typeof latestMessage === "object" && latestMessage.type === "move") {
            const { newPosition, symbol, diceValue } = latestMessage.message;
            
            if (symbol !== playerSymbol) {
                setOpponentPlayerPosition(newPosition);
                setRoll(diceValue);
                setIsRedNext(symbol === "red" ? false : true);
            }
        }
    }, [messages]);

    const rollDice = () => {
        if (gameOver || (playerSymbol === "red" && !isRedNext) || (playerSymbol === "blue" && isRedNext)) {
            return;
        }

        const diceValue = Math.floor(Math.random() * 6) + 1;
        setRoll(diceValue);
        movePlayer(diceValue);
    };

    const movePlayer = (diceValue) => {
        setPlayerPosition((prevPos) => {
            let newPosition = prevPos + diceValue;

            if (newPosition > gridSize * gridSize) {
                newPosition = prevPos;
            } else {
                newPosition = snakes[newPosition] || ladders[newPosition] || newPosition;
            }

            if (newPosition === gridSize * gridSize) {
                setGameOver(true);
                alert(`${playerSymbol.toUpperCase()} wins!`);
            }

            send({ type: "move", message: { newPosition, symbol: playerSymbol, diceValue } });

            setIsRedNext(playerSymbol === "red" ? false : true);
            return newPosition;
        });
    };

    const getCoordinates = (position) => {
        const col = (position - 1) % gridSize;
        const row = Math.floor((position - 1) / gridSize);
    
        const cellSize = 55;
        return {
            x: col * cellSize + cellSize / 2,
            y: row * cellSize + cellSize / 2,
        };
    };  
    
    const color = {
        'red': "🔴",
        'blue': "🔵"
    }

    return (
        <div className="game-container">
            <h1 className="game-title">Snake and Ladder - Room: {roomName}</h1>
            <h2 className={`turn-indicator ${isRedNext ? "red-turn" : "blue-turn"}`}>
                {isRedNext ? "Red's turn 🔴" : "Blue's turn 🔵"}
            </h2>

            <div className="board-container">
                <svg className="board-svg">
                    {Object.entries(snakes).map(([start, end]) => {
                        const startCoords = getCoordinates(Number(start));
                        const endCoords = getCoordinates(Number(end));
                        return (
                            <line key={`snake-${start}`} x1={startCoords.x} y1={startCoords.y} 
                                  x2={endCoords.x} y2={endCoords.y} className="snake-line" />
                        );
                    })}
                    {Object.entries(ladders).map(([start, end]) => {
                        const startCoords = getCoordinates(Number(start));
                        const endCoords = getCoordinates(Number(end));
                        return (
                            <line key={`ladder-${start}`} x1={startCoords.x} y1={startCoords.y} 
                                  x2={endCoords.x} y2={endCoords.y} className="ladder-line" />
                        );
                    })}
                </svg>

                <div className="board" style={{ gridTemplateColumns: `repeat(${gridSize}, 1fr)` }}>
                    {Array.from({ length: gridSize * gridSize }, (_, index) => {
                        const position = index + 1;
                        return (
                            <div key={position} className="cell">
                                {position in snakes && <span className="snake">🐍</span>}
                                {position in ladders && <span className="ladder">🪜</span>}
                                {playerPosition === position ? color[playerSymbol] : 
                                 opponentPlayerPosition === position ? color[playerSymbol === "red" ? "blue" : "red"] : 
                                 position}
                            </div>
                        );
                    })}
                </div>
            </div>

            <button className="roll-dice" onClick={rollDice} 
                disabled={gameOver || (playerSymbol === "red" && !isRedNext) || (playerSymbol === "blue" && isRedNext)}>
                🎲 Roll Dice
            </button>

            {roll !== null && <h3 className="dice-result">Dice Roll: {roll}</h3>}
        </div>
    );
};

export default SnakeAndLadder;
