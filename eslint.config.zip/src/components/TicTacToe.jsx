import { useState, useEffect } from "react";
import { useParams, useLocation } from "react-router-dom";
import { useWebSocket } from "./WebsocketContext";

function generateWinningLines(gridSize, winningLineLength) {
    const lines = [];
  
    // Horizontal lines
    for (let row = 0; row < gridSize; row++) {
      for (let col = 0; col <= gridSize - winningLineLength; col++) {
        const line = [];
        for (let i = 0; i < winningLineLength; i++) {
          line.push(row * gridSize + (col + i));
        }
        lines.push(line);
      }
    }
  
    // Vertical lines
    for (let col = 0; col < gridSize; col++) {
        for (let row = 0; row <= gridSize - winningLineLength; row++) {
            const line = [];
            for (let i = 0; i < winningLineLength; i++) {
                line.push((row + i) * gridSize + col);
            }
            lines.push(line);
        }
    }
  
    // Diagonal lines
    for (let row = 0; row <= gridSize - winningLineLength; row++) {
        for (let col = 0; col <= gridSize - winningLineLength; col++) {
            const line1 = [];
            const line2 = [];
            for (let i = 0; i < winningLineLength; i++) {
                line1.push((row + i) * gridSize + (col + i));
                line2.push((row + i) * gridSize + (col + winningLineLength - 1 - i));
            }
            lines.push(line1);
            lines.push(line2);
        }
    }
  
    return lines;
}

function calculateWinner(squares, winningLines) {
    for (let line of winningLines) {
        const firstSymbol = squares[line[0]];
        if (firstSymbol && line.every(index => squares[index] === firstSymbol)) {
            return firstSymbol;
        }
    }
    return null;
}

const TicTacToe = () => {
    const { roomName } = useParams();
    const location = useLocation();
    const playerSymbol = location.state?.symbol;
    const gridSize = location.state?.config?.gridSize;
    const winLength = location.state?.config?.winLength;
    const { messages, send } = useWebSocket();
    const [board, setBoard] = useState(Array(gridSize*gridSize).fill(null));
    const [isXNext, setIsXNext] = useState(true);
    const [lastMessage, setLastMessage] = useState(null);
    const winningLines = generateWinningLines(gridSize, winLength);

    useEffect(() => {
        if (!messages.length) return;
        const latestMessage = messages[messages.length - 1];

        if (latestMessage === lastMessage) return;

        setLastMessage(latestMessage);

        if (typeof latestMessage === "object" && latestMessage.type === "move") {
            const { index, symbol } = latestMessage.message;
            handleMove(index, symbol);
        }
    }, [messages]);

    const handleMove = (index, symbol) => {
        setBoard((prevBoard) => {
            const newBoard = [...prevBoard];
            newBoard[index] = symbol;
            return newBoard;
        });
        setIsXNext(symbol === "X" ? false : true);
        const winner = calculateWinner(board, winningLines);
        if (winner) {
            alert(`Player ${winner} wins!`);
        }
    };

    const handleClick = (index) => {
        if (board[index] || playerSymbol !== (isXNext ? "X" : "O")) return;
        handleMove(index, playerSymbol);
        send({ type: "move", message: { index: index, symbol: playerSymbol } });
    };

    return (
        <div>
            <h1>Tic Tac Toe - Room: {roomName}</h1>
            <div style={{ display: "grid", gridTemplateColumns: `repeat(${gridSize}, 100px)`, gap: "5px" }}>
                {board.map((cell, index) => (
                    <button key={index} onClick={() => handleClick(index)} style={{ width: "100px", height: "100px", fontSize: "24px" }}>
                        {cell}
                    </button>
                ))}
            </div>
            <h2>You are: {playerSymbol}</h2>
            <h3>{isXNext ? "X's turn" : "O's turn"}</h3>
        </div>
    );
};

export default TicTacToe;