import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useWebSocket } from './WebsocketContext';
//import './Room.css';

const predefinedGames = [
    { 
        name: "Tic Tac Toe", 
        options: { 
            gridSize: 3, 
            winLength: 3,
            //symbol: ["X", "O"]
        }
    },
    { 
        name: "Connect 4", 
        options: { 
            gridSize: 6, 
            winLength: 4,
            //color: ["blue", "red"]
        }
    },
    { 
        name: "Snake And Ladder", 
        options: { 
            gridSize: 10, 
            snakes: {16: 6, 47: 26, 59: 40, 62: 19, 87: 24, 98: 78}, 
            ladders: {4: 14, 21: 42, 28: 84, 38: 57, 51: 67, 71: 91},
            //color: ["blue", "red"]
        }
    }
];

const Room = () => {
    const { roomName } = useParams();
    const navigate = useNavigate();
    const { connectToRoom, send, messages } = useWebSocket();
    const [message, setMessage] = useState('');
    const [chat, setChat] = useState([]);
    const [selectedGame, setSelectedGame] = useState('');
    const [config, setConfig] = useState(predefinedGames[0].options);
    const [gameStarted, setGameStarted] = useState(false);

    useEffect(() => {
        connectToRoom(roomName);
    }, [roomName, connectToRoom]);

    useEffect(() => {
        if (!messages || messages.length === 0) return;
        
        const lastMessage = messages[messages.length - 1];

        if (!lastMessage || typeof lastMessage !== 'object') return;

        console.log("Received:", lastMessage);

        if (lastMessage.type === "chat_message") {
            setChat((prevChat) => [...prevChat, lastMessage]);
        } else if (lastMessage.type === "start_game" && !gameStarted) {
            setGameStarted(true);
            console.log("Starting game with symbol:", lastMessage.message.symbol);
            if (lastMessage.message.game.name === "Tic Tac Toe") {
                navigate(
                    `/game/tic-tac-toe/${roomName}`, 
                    { 
                        state: { game: lastMessage.message.game, config: lastMessage.message.config, symbol: lastMessage.message.symbol } 
                    }
                );
            }
            else if (lastMessage.message.game.name === "Snake And Ladder") {
                navigate(
                    `/game/snake-and-ladder/${roomName}`,
                    {
                        state: { game: lastMessage.message.game, config: lastMessage.message.config, symbol: lastMessage.message.symbol }
                    }
                );
            }
        }
    }, [messages, gameStarted]);

    const handleGameChange = (event) => {
        const game = predefinedGames.find(g => g.name === event.target.value);
        setSelectedGame(game);
        setConfig(game.options);
    };

    const handleInputChange = (e) => {
        setConfig({ ...config, [e.target.name]: e.target.value });
    };

    const handleAddEntry = (type) => {
        const start = parseInt(prompt(`Enter start position of ${type}:`), 10);
        const end = parseInt(prompt(`Enter end position of ${type}:`), 10);
        if (start && end && start !== end) {
            setConfig({
                ...config,
                [type]: { ...config[type], [start]: end }
            });
        }
    };

    // Handle removing a snake or ladder
    const handleRemoveEntry = (type, key) => {
        const updatedEntries = { ...config[type] };
        delete updatedEntries[key];
        setConfig({ ...config, [type]: updatedEntries });
    };

    const handleSendMessage = () => {
        if (!message.trim()) return;
        send({ type: "chat_message", message, id: Date.now() });
        setMessage('');
    };

    const startGame = () => {
        if (!gameStarted) {
            console.log("Selected game:", selectedGame);
            if (selectedGame.name === "Tic Tac Toe") {
                const assignedSymbol = Math.random() < 0.5 ? 'X' : 'O';
                setGameStarted(true);
                send({ type: "start_game", message: {game: selectedGame, config: config, symbol: assignedSymbol === 'X' ? 'O' : 'X' }});
                console.log("Starting game with symbol:", assignedSymbol);
                navigate(
                    `/game/tic-tac-toe/${roomName}`, 
                    { 
                        state: { game: selectedGame.name, config: config, symbol: assignedSymbol } 
                    }
                );
            }
            else if (selectedGame.name === "Snake And Ladder") {
                setGameStarted(true);
                const assignedSymbol = Math.random() < 0.5 ? 'red' : 'blue';
                send({ type: "start_game", message: {game: selectedGame, config: config, symbol: assignedSymbol === 'red' ? 'blue' : 'red' }});
                console.log("Starting game with symbol:", assignedSymbol);
                navigate(
                    `/game/snake-and-ladder/${roomName}`, 
                    {
                        state: { game: selectedGame.name, config: config, symbol: assignedSymbol }
                    }
                );
            }
        }
    };

    return (
      <div>
          <h1>Room: {roomName}</h1>
          <div>
              <h2>Chat</h2>
              <ul>
                  {chat.map((msg, index) => (
                      <li key={index}><strong>{msg.user || 'Anonymous'}:</strong> {msg.message}</li>
                  ))}
              </ul>
              <input 
                  type="text" 
                  placeholder="Type your message" 
                  value={message} 
                  onChange={(e) => setMessage(e.target.value)} 
              />
              <button onClick={handleSendMessage}>Send</button>
          </div>
          <div>
              <h1>Select a Game</h1>
              <select value={selectedGame.name} onChange={handleGameChange}>
                  {predefinedGames.map((game, index) => (
                      <option key={index} value={game.name}>{game.name}</option>
                  ))}
              </select>

              <h2>Game Configuration</h2>
              <label>Grid Size: </label>
              <input type="number" name="gridSize" value={config.gridSize} onChange={handleInputChange} /><br/>

              {config.winLength !== undefined && (
                  <>
                      <label>Win Length: </label>
                      <input type="number" name="winLength" value={config.winLength} onChange={handleInputChange} /><br/>
                  </>
              )}

              {config.snakes && (
                  <>
                      <h3>Snakes</h3>
                      <ul>
                          {Object.entries(config.snakes).map(([start, end]) => (
                              <li key={start}>{start} → {end} <button onClick={() => handleRemoveEntry('snakes', start)}>Remove</button></li>
                          ))}
                      </ul>
                      <button onClick={() => handleAddEntry('snakes')}>Add Snake</button>
                  </>
              )}

              {config.ladders && (
                  <>
                      <h3>Ladders</h3>
                      <ul>
                          {Object.entries(config.ladders).map(([start, end]) => (
                              <li key={start}>{start} → {end} <button onClick={() => handleRemoveEntry('ladders', start)}>Remove</button></li>
                          ))}
                      </ul>
                      <button onClick={() => handleAddEntry('ladders')}>Add Ladder</button>
                  </>
              )}
          </div>
          <button onClick={startGame} disabled={gameStarted} style={{ marginTop: '20px' }}>
              Start Game
          </button>
      </div>
  );    
};

export default Room;